package viceCity;

import viceCity.core.ControllerImpl;
import viceCity.core.EngineImpl;
import viceCity.core.interfaces.Controller;
import viceCity.core.interfaces.Engine;
import viceCity.models.players.MainPlayer;

public class Main {
    public static void main(String[] args) {
        MainPlayer player = new MainPlayer();
        Controller controller = new ControllerImpl(player);
        Engine engine = new EngineImpl(controller);
        engine.run();
    }
}

/*
AddGun Pistol Colt
AddGun Rifle SniperRifle
AddPlayer Alfie
AddPlayer Alexis
AddPlayer Bean
AddPlayer Beck
AddPlayer Camber
AddPlayer Burney
Fight
AddGunToPlayer Vercetti
AddGunToPlayer Vercetti
AddGunToPlayer Vercetti
Fight
Exit

 */
