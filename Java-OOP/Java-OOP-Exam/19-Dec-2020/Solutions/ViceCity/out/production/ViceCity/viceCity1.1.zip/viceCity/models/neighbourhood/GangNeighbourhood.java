package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood {

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {

        Collection<Gun> mainPlayerGuns = mainPlayer.getGunRepository().getModels();
        Collection<Player> deadPlayers = new ArrayList<>();

        for (Gun gun : mainPlayerGuns) {
            boolean emptyGun = false;
            for (Player civilPlayer : civilPlayers) {
                while (civilPlayer.isAlive()) {
                    if (gun.canFire()) {
                        civilPlayer.takeLifePoints(gun.fire());
                    } else {
                        emptyGun = true;
                        break;
                    }
                }
                if (!civilPlayer.isAlive() && !deadPlayers.contains(civilPlayer)) {
                    deadPlayers.add(civilPlayer);
                }

                if (emptyGun) {
                    break;
                }
            }
        }
        civilPlayers.removeAll(deadPlayers);

        for (Player civilPlayer : civilPlayers) {
            Collection<Gun> civilPlayerGuns = civilPlayer.getGunRepository().getModels();
            for (Gun gun : civilPlayerGuns) {
                while (mainPlayer.isAlive()) {
                    if (gun.canFire()) {
                        mainPlayer.takeLifePoints(gun.fire());
                    } else {
                        break;
                    }
                }
                if (!mainPlayer.isAlive()) {
                    return;
                }
            }
        }
    }
}
